MY STUDY TIMER — ANDROID HOME-SCREEN APP

Files:
- index.html: app
- manifest.json: installable app settings
- sw.js: offline cache
- icon.svg: app icon

IMPORTANT:
A Progressive Web App must be hosted on HTTPS (or localhost) for service workers and installation to work. Opening index.html directly from a file manager will let you try the timer, but will not install it as a proper PWA.

Simple publishing option:
1. Create a repository on GitHub and upload all four app files to the repository root.
2. In the repository, open Settings > Pages.
3. Under Build and deployment, choose Deploy from a branch; select the main branch and /(root), then Save.
4. Wait for GitHub Pages to publish the site. Open the HTTPS URL it gives you in Chrome on your Android phone.
5. In Chrome, tap ⋮ > Install app (or Add to Home screen).

Your task list is stored locally in the browser on that device. Clearing browser site data may remove it. Keep the app open while a timer is running.
